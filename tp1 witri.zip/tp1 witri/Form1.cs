﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tp1_witri
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void login_Click(object sender, EventArgs e)
        {
            User user = new User();
            string username = tbusername.Text;
            string password = tbpassword.Text;

            user.Username = Convert.ToString(username);
            user.Password = Convert.ToString(password);

            if (username.Trim() == string.Empty || password.Trim() == string.Empty)
            {
                MessageBox.Show("Harap isi Username dan Password Anda");
            }
            else
            {
                if (password == "pbo123")
                {
                    Form2 form2 = new Form2();
                    form2.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Maaf Password yang anda masukan salah");
                }
            }
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            
        }
    }
}
