﻿namespace tp1_witri
{
    internal class User
    {
        public string Username { get; internal set; }
        public string Password { get; internal set; }
    }
}